from django import forms
class register(forms.Form):
    name=forms.CharField(label="Enter your Name",max_length=10)
    phno=forms.CharField(label="Enter your Number",max_length=10)
    email=forms.CharField(label="Enter your Email ID",max_length=10)