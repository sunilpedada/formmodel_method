from django.apps import AppConfig


class FmsampConfig(AppConfig):
    name = 'fmsamp'
