from django.shortcuts import render
from.form import register
from django.views.generic import View
from.models import input

# Create your views here
class forms(View):
    def get(self,request):
        r = register()
        return render(request,"register.html",{"result":r})
    def post(self,request):
        a=request.POST["name"]
        b=int(request.POST["phno"])
        c=request.POST["email"]
        f=input(name=a,phno=b,emailid=c)
        f.save()
        return render(request, "home.html")
class display(View):
    def get(self,request):
        w = input.objects.all()
        return render(request,"display.html",{"input":w})