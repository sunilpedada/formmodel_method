from django.conf.urls import url
from.views import forms,display
urlpatterns=[ url(r"^$",forms.as_view(),name="forms"),
              url(r"^display$",display.as_view(),name="display"),]